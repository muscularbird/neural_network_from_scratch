PIECES = {
    "": 0,
    "P": 1,
    "N": 2,
    "B": 3,
    "R": 4,
    "Q": 5,
    "K": 6,
    "p": -1,
    "n": -2,
    "b": -3,
    "r": -4,
    "q": -5,
    "k": -6
}

POSITIONS = [
    "Checkmate Black",
    "Checkmate White",
    "Check Black",
    "Check White",
    "Nothing"
]
